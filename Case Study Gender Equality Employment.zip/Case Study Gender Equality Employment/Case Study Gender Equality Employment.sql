/*
A company wants to assess its gender equality employment policy by looking 
into the number of male and female employees in the company. 
Please find: 
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Case Study: Gender Equality Employment <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
______________________________________________________________________________*/
# use database employees
use employees;

# 1- The number of male and female employees in the company. 
SELECT distinct gender,count(emp_no) as count_employees
FROM employees
GROUP BY gender;

#______________________________________________________________________________#

# 2- The ratio of males to females hired in the last 5 years. 
SELECT sum(case when `Gender` = 'M' then 1 else 0 end)/count(*) as Male_Ratio,
       sum(case when `Gender` = 'F' then 1 else 0 end)/count(*) as Female_Ratio
FROM employees
WHERE (hire_date between '1995-01-01' and '2000-12-31') ;

#______________________________________________________________________________#

/* 3- If the ratio is not 1:1,
list the departments that have the highest gaps in descending order */
SELECT  dept_name, count(dept_name) as count_emp, gender
FROM dept_emp
LEFT JOIN departments
ON departments.dept_no = dept_emp.dept_no
LEFT JOIN employees
ON dept_emp.emp_no = employees.emp_no
GROUP BY dept_name,gender
ORDER BY  count_emp DESC;

#______________________________________________________________________________#

/* 4- Diffreence between males to females */ 
SELECT dept_no, 
    (  sum(case when `gender` = 'M' then 1 else 0 end) -
       sum(case when `gender` = 'F' then 1 else 0 end)) as difference
FROM employees 
JOIN  dept_emp on employees.emp_no = dept_emp.emp_no
GROUP BY dept_no
ORDER BY difference desc; 
#______________________________________________________________________________#

/* 5- Average salary for males and females*/

 #The average salary for males 
SELECT avg(salary),gender 
FROM salaries 
JOIN employees 
ON salaries.emp_no = employees.emp_no
WHERE gender ='M';

 #The average salary for females 
SELECT avg(salary),gender 
FROM salaries 
JOIN employees 
ON salaries.emp_no = employees.emp_no
WHERE gender ='F';

#______________________________________________________________________________#

/* 6- Find the gap in each department */
SELECT dept_name, (salary) as salarry, gender
FROM dept_emp d
LEFT JOIN departments dee
ON dee.dept_no = d.dept_no
LEFT JOIN salaries  s
ON d.emp_no = s.emp_no
JOIN employees e 
ON e.emp_no = d.emp_no
WHERE ( hire_date between '1995-1-1' and '2000-12-31')
GROUP BY dept_name,gender
ORDER BY  salary DESC;